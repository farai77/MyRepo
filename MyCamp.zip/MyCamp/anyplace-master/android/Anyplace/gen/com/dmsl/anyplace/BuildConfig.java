/** Automatically generated file. DO NOT MODIFY */
package com.dmsl.anyplace;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}