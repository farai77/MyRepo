Eclipse Projects: 
Version: Luna 4.4.2
Compile:
Project Actionbarsherlock 
Java Build Path
Order and Export 
Check android-support-v4.jar 

library -- Google Maps Android API Utility Library
 Fixed Bug HeatmapTileProvider.java